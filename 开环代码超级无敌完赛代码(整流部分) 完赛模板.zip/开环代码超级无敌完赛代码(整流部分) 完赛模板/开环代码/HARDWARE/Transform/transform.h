#ifndef __TRANSFORM_H
#define __TRANSFORM_H

#include "math.h"

#define pi  3.141592653f

/* Clark Transform */
typedef struct
{
    float ua;
    float ub;
    float uc;
    float alpha;
    float beta;
    float u0;
}CLARK_STRUCT;

void Clark_Init(CLARK_STRUCT*p);
void Clark_Func(CLARK_STRUCT*p,float ua,float ub,float uc,int sele);
void iClark_Func(CLARK_STRUCT*p,float alpha,float beta,float u0,int sele);

/* Park Transform */
typedef struct
{
    float alpha;
    float beta;
    float ud;
    float uq;
    float theta;
}PARK_STRUCT;

void Park_Init(PARK_STRUCT*p);
void Park_Func(PARK_STRUCT*p,float alpha,float beta,float theta,int park_sele);
void iPark_Func(PARK_STRUCT*p,float ud,float uq,float theta,int park_sele);

/* abc to dq0 Transform */
typedef struct
{
    float ua;
    float ub;
    float uc;
    float ud;
    float uq;
    float u0;
    float theta;
}ABC_DQ0_STRUCT;

void abc_dq0_Init(ABC_DQ0_STRUCT*p);
void abcTodq0_Func(ABC_DQ0_STRUCT*p,float ua,float ub,float uc,float theta,int sele);
void dq0Toabc_Func(ABC_DQ0_STRUCT*p,float ud,float uq,float u0,float theta,int sele);

#endif
#include "transform.h"


void Clark_Init(CLARK_STRUCT*p)
{
    p->ua=0;
    p->ub=0;
    p->uc=0;
    p->alpha=0;
    p->beta=0;
    p->u0=0;
}

/* abc to alpha beta 0 */
void Clark_Func(CLARK_STRUCT*p,float ua,float ub,float uc,int sele)
{
    if(sele==1)
    {
        /* A & alpha */
        p->alpha = 0.6667*(ua - 0.5*ub - 0.5*uc);
        p->beta  = 0.6667*(0.866*ub - 0.866*uc);
        p->u0    = 0.6667*(0.5*ua + 0.5*ub + 0.5*uc);
    }
    else
    {
        /* A & alpha - 90 */
        p->alpha = 0.6667*(-0.866*ub + 0.866*uc);
        p->beta  = 0.6667*(ua - 0.5*ub - 0.5*uc);
        p->u0    = 0.6667*(0.5*ua + 0.5*ub + 0.5*uc);
    }
}

/* alpha beta 0 to abc */
void iClark_Func(CLARK_STRUCT*p,float alpha,float beta,float u0,int sele)
{
    if(sele==1)
    {
        /* A & alpha */
        p->ua = (alpha + u0);
        p->ub = (-0.5*alpha + 0.866*beta + u0);
        p->uc = (-0.5*alpha - 0.886*beta + u0);
    }
    else
    {
        /* A & alpha - 90 */
        p->ua = (beta + u0);
        p->ub = (-0.866*alpha - 0.5*beta + u0);
        p->uc = ( 0.866*alpha - 0.5*beta + u0);
    }
}

void Park_Init(PARK_STRUCT*p)
{
    p->alpha=0;
    p->beta=0;
    p->theta=0;
    p->ud=0;
    p->uq=0;
}

/* alpha beta 0 to dq0 */
void Park_Func(PARK_STRUCT*p,float alpha,float beta,float theta,int park_sele)
{

    float p_cos=cos(theta);
    float p_sin=sin(theta);
    if(park_sele==1)
    {
        /* cos */
        p->ud = p_cos * alpha + p_sin * beta;
        p->uq = p_cos * beta  - p_sin * alpha; 
    }
    else
    {
        /* sin */
        p->ud = p_sin * alpha - p_cos * beta;
        p->uq = p_cos * alpha + p_sin * beta;  
    }
}

/* dq0 to alpha beta 0 */
void iPark_Func(PARK_STRUCT*p,float ud,float uq,float theta,int park_sele)
{
    float p_cos=cos(theta);
    float p_sin=sin(theta);
    if(park_sele==1)
    {
        /* cos */
        p->alpha = p_cos * ud - p_sin * uq;
        p->beta  = p_sin * ud + p_cos * uq;
    }
    else
    {
        /* sin */
        p->alpha =  p_sin * ud + p_cos * uq;
        p->beta  = -p_cos * ud + p_sin * uq;
    }
}

void abc_dq0_Init(ABC_DQ0_STRUCT*p)
{
    p->ua=0;
    p->ub=0;
    p->uc=0;
    p->ud=0;
    p->uq=0;
    p->u0=0;
    p->theta=0;
}

/* abc to dq0 */
void abcTodq0_Func(ABC_DQ0_STRUCT*p,float ua,float ub,float uc,float theta,int sele)
{
    float p_sin0=sin(theta);
    float p_sin1=sin(theta-2*pi/3);
    float p_sin2=sin(theta+2*pi/3);
    float p_cos0=cos(theta);
    float p_cos1=cos(theta-2*pi/3);
    float p_cos2=cos(theta+2*pi/3);

    if(sele==1)
    {
        /* sin */
        p->ud = 0.6667 * (p_sin0 * ua + p_sin1 * ub + p_sin2 *uc);
        p->uq = 0.6667 * (p_cos0 * ua + p_cos1 * ub + p_cos2 *uc);
        p->u0 = 0.6667 * (0.5 * ua + 0.5 * ub + 0.5 * uc);
    }
    else
    {
        /* cos */
        p->ud =   0.6667 * (p_cos0 * ua + p_cos1 * ub + p_cos2 *uc);
        p->uq = - 0.6667 * (p_sin0 * ua + p_sin1 * ub + p_sin2 *uc);
        p->u0 =   0.6667 * (0.5 * ua + 0.5 * ub + 0.5 * uc);
    }
}

/* dq0 to abc */
void dq0Toabc_Func(ABC_DQ0_STRUCT*p,float ud,float uq,float u0,float theta,int sele)
{
    float p_sin0=sin(theta);
    float p_sin1=sin(theta-2*pi/3);
    float p_sin2=sin(theta+2*pi/3);
    float p_cos0=cos(theta);
    float p_cos1=cos(theta-2*pi/3);
    float p_cos2=cos(theta+2*pi/3);

    if(sele==1)
    {
        /* sin */
        p->ua = (p_sin0 * ud + p_cos0 * uq + u0);
        p->ub = (p_sin1 * ud + p_cos1 * uq + u0);
        p->uc = (p_sin2 * ud + p_cos2 * uq + u0);
    }
    else
    {
        /* cos */
        p->ua = (p_cos0 * ud - p_sin0 * uq + u0);
        p->ub = (p_cos1 * ud - p_sin1 * uq + u0);
        p->uc = (p_cos2 * ud - p_sin2 * uq + u0);
    }
}


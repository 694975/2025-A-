#ifndef __PID_H
#define __PID_H
typedef struct
{
    float kp, ki, kd; //����ϵ��
    float error, lastError; //���ϴ����
    float integral, maxIntegral; //���֡������޷�
    float output, maxOutput; //���������޷�
}PIDControl;
extern  PIDControl Current_PID,EXCurrent_PID;
extern  PIDControl Volatile_PID;
extern  PIDControl DC_PID;
extern  float AD_current_ref;
void Current_PID_Init(PIDControl*PID);
void EXCurrent_PID_Init(PIDControl*PID);
void Volatile_PID_Init(PIDControl*PID);
void PID_Init(void);
void Volatile_DCPID_Init(PIDControl*PID);
float PID_Calc(PIDControl *pid, float error);
float PID_Current_calc(float error);
float PID_Volatite_calc(float error);
#endif

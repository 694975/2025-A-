
#include "stm32f4xx.h"                  // Device header
#include "PID.h"
PIDControl Current_PID, EXCurrent_PID;
PIDControl Volatile_PID;
PIDControl DC_PID;
void Current_PID_Init(PIDControl*PID)
{
PID->kp=0.002;  
PID->ki=0;
PID->kd=0;
PID->maxIntegral=0;
PID->maxOutput=40;
}
void Volatile_PID_Init(PIDControl*PID)
{
PID->kp=0.002;
PID->ki=0.000001;
PID->kd=0;
PID->maxIntegral=0.01;
PID->maxOutput=0.05;
}
void Volatile_DCPID_Init(PIDControl*PID)
{
PID->kp=0.001;
PID->ki=0;
PID->kd=0;
PID->maxOutput=10;
}
void EXCurrent_PID_Init(PIDControl*PID)
{
PID->kp=-0.01;  
PID->ki=0;
PID->kd=0;
PID->maxOutput=20;
}
void PID_Init(void)
{
	 Current_PID_Init(&Current_PID);
   Volatile_PID_Init(&Volatile_PID);
	 EXCurrent_PID_Init(&EXCurrent_PID);
}
//λ��ʽPID
float PID_Calc(PIDControl *pid, float error)
{
    //��������
    pid->lastError = pid->error; //����error������
    pid->error = error ; //������error
    //����΢��
    float dout = (pid->error - pid->lastError) * pid->kd;
    //�������
    float pout = pid->error * pid->kp;
    //�������
    pid->integral += pid->error * pid->ki;
    //�����޷�
    if(pid->integral > pid->maxIntegral) pid->integral = pid->maxIntegral;
    else if(pid->integral < -pid->maxIntegral) pid->integral = -pid->maxIntegral;
    //�������
    pid->output = pout+dout + pid->integral;
    //����޷�
    if(pid->output > pid->maxOutput) pid->output =   pid->maxOutput;
    else if(pid->output < -pid->maxOutput) pid->output = -pid->maxOutput;
    return pid->output;
}
//����ʽPID

//PID����
float PID_Current_calc(float error)
{
   return PID_Calc(&Current_PID,error);
}
float PID_Volatite_calc(float error)
{
   return PID_Calc(&Volatile_PID,error);
}




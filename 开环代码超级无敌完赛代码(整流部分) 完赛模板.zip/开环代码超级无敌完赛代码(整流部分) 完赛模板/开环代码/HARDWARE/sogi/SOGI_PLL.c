#include "SOGI_PLL.h"
#include "usart.h"
#include "adc.h"
#include "arm_math.h"
// ======================== SOGI ģ��ʵ�� ========================
void SOGI_UpdateCoefficients(float Ts, float w, float k, SOGI_Coefficients* coeff) {
    coeff->a0 = 4.0f + 2.0f * k * w * Ts + w * w * Ts * Ts;
    coeff->a1 = -8.0f + 2.0f * w * w * Ts * Ts;
    coeff->a2 = 4.0f - 2.0f * k * w * Ts + w * w * Ts * Ts;
    
    const float num_d_factor = 2.0f * k * w * Ts;
    coeff->b0_d = num_d_factor;
    coeff->b1_d = 0.0f;
    coeff->b2_d = -num_d_factor;
    
    const float num_q_factor = k * w * w * Ts * Ts;
    coeff->b0_q = num_q_factor;
    coeff->b1_q = 2.0f * num_q_factor;
    coeff->b2_q = num_q_factor;
    
    const float inv_a0 = 1.0f / coeff->a0;
    coeff->B0_d = coeff->b0_d * inv_a0;
    coeff->B1_d = coeff->b1_d * inv_a0;
    coeff->B2_d = coeff->b2_d * inv_a0;
    coeff->B0_q = coeff->b0_q * inv_a0;
    coeff->B1_q = coeff->b1_q * inv_a0;
    coeff->B2_q = coeff->b2_q * inv_a0;
    coeff->A1 = coeff->a1 * inv_a0;
    coeff->A2 = coeff->a2 * inv_a0;
}

void SOGI_ProcessSample(SOGI_State* state, float input) {
    state->u[2] = state->u[1];
    state->u[1] = state->u[0];
    state->u[0] = input;
    
    SOGI_Coefficients* c = state->coeff;
    
    state->v_prime[0] = 
        c->B0_d * state->u[0] + 
        c->B1_d * state->u[1] + 
        c->B2_d * state->u[2] - 
        c->A1 * state->v_prime[1] - 
        c->A2 * state->v_prime[2];
    
    state->v_prime[2] = state->v_prime[1];
    state->v_prime[1] = state->v_prime[0];
    
    state->qv_prime[0] = 
        c->B0_q * state->u[0] + 
        c->B1_q * state->u[1] + 
        c->B2_q * state->u[2] - 
        c->A1 * state->qv_prime[1] - 
        c->A2 * state->qv_prime[2];
    
    state->qv_prime[2] = state->qv_prime[1];
    state->qv_prime[1] = state->qv_prime[0];
}

void SOGI_InitState(SOGI_State* state, SOGI_Coefficients* coeff) {
    memset(state, 0, sizeof(SOGI_State));
    state->coeff = coeff;
}

// ======================== Park�任ģ��ʵ�� ========================
void Park_Transform(PARK_Transform *p) {
    p->d = p->alpha * p->cos + p->beta * p->sin;
    p->q = -p->alpha * p->sin + p->beta * p->cos;
}

// ======================== PID������ģ��ʵ�� ========================
float positional_pid_update(PID_Controller1 *pid, float error)
{
    // 1. ���������
    float P = pid->Kp * error;   
    // 2. ��������㣨���޷���
    pid->integral += error * pid->Ts;
    // ���ֿ�����
    if (pid->integral > pid->max_integral) 
        pid->integral = pid->max_integral;
    else if (pid->integral < pid->min_integral) 
        pid->integral = pid->min_integral;
    float I = pid->Ki * pid->integral;
    // 3. ΢�������
    float derivative = (error - pid->prev_error) / pid->Ts;
    float D = pid->Kd * derivative;
    // 4. �ϳ����
    float output = P + I + D;  
    // 5. ����޷�
    if (output > pid->max_output) 
        output = pid->max_output;
    else if (output < pid->min_output) 
        output = pid->min_output; 
    // 6. ����״̬
    pid->prev_error = error;
    return output;
}

// ======================== �򻯵�VCOģ��ʵ�� ========================
void processVCO_Bilinear(VCO_State* state, float ylf) {
    // ��ʵ�֣�ֱ��ʹ��Ƶ��У����
    state->fo = state->fn + ylf;
    
    // ��λ����
    state->theta[0] += TWO_PI_F * state->fo * state->delta_T;
    
    // ��λ��װ
    while (state->theta[0] > TWO_PI_F) state->theta[0] -= TWO_PI_F;
    while (state->theta[0] < 0) state->theta[0] += TWO_PI_F;
    
    // �������Ǻ���
    state->sin = arm_sin_f32(state->theta[0]);
    state->cos = arm_cos_f32(state->theta[0]);
}

// ======================== SOGI-PLL���ṹʵ�� ========================
void SOGI_PLL_Init(SOGI_PLL *pll, float Ts, float fn, float k, float kp_pi, float ki_pi, float kd_pd, 
                   float max_integral, float min_integral, float max_output, float min_output) {
    memset(pll, 0, sizeof(SOGI_PLL));
    pll->Ts = Ts;
    pll->fn = fn;
    pll->k = k;
    pll->kp_pi = kp_pi;
    pll->ki_pi = ki_pi;
    
    // ��ʼ��SOGI
    SOGI_InitState(&pll->sogi, &pll->sogi_coeff);
    
    // ��ʼ��λ��ʽPID
    pll->pid1.Kp = kp_pi;
    pll->pid1.Ki = ki_pi;
    pll->pid1.Kd = kd_pd;
    pll->pid1.prev_error = 0;
    pll->pid1.integral = 0;
    pll->pid1.max_integral = max_integral;
    pll->pid1.min_integral = min_integral;
    pll->pid1.max_output = max_output;
    pll->pid1.min_output = min_output; 
    pll->pid1.Ts = Ts;
    
    // ��ʼ��VCO
    pll->vco.fo = fn;
    pll->vco.fn = fn;
    pll->vco.delta_T = Ts;
    pll->vco.cos = 1.0f;  // cos(0) = 1
    
    // �����ʼ��
    pll->freq = fn;
    
    // ����SOGIϵ��
    SOGI_UpdateCoefficients(pll->Ts, TWO_PI_F * pll->vco.fo, pll->k, &pll->sogi_coeff);
}

void SOGI_PLL_ProcessSample(SOGI_PLL *pll, float input) {
    static float acFreq = 0;
    
    // 1. ����SOGI
    SOGI_ProcessSample(&pll->sogi, input);
    
    // 2. ׼��Park�任����
    pll->park.alpha = pll->sogi.v_prime[0];  // ͬ�����
    pll->park.beta = pll->sogi.qv_prime[0];   // ��������
    
    // 3. ���õ�ǰ��λ��Ϣ
    pll->park.sin = pll->vco.sin;
    pll->park.cos = pll->vco.cos;
    
    // 4. ִ��Park�任
    Park_Transform(&pll->park);
	  //pll->park.q_FIT=0.99f*pll->park.q_FIT+0.01f*>park.q
    // 5. ʹ��λ��ʽPID���� (ʹ��q�������Ϊ���)
    pll->ylf_total = positional_pid_update(&pll->pid1, pll->park.q);
    // 6. ���¼򻯵�VCO
    processVCO_Bilinear(&pll->vco, pll->ylf_total);
		    
    // 7. �������
    pll->phase = pll->vco.theta[0];
    acFreq = acFreq + (pll->vco.fo - acFreq) * 0.00005f;  // ��ͨ�˲�
    pll->freq = acFreq;
    pll->amplitude = sqrtf(pll->park.alpha * pll->park.alpha + 
                          pll->park.beta * pll->park.beta);
}

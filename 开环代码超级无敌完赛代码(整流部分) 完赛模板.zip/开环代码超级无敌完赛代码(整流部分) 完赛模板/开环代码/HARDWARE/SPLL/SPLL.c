#include "SPLL.h"

/*
 *@brief 二阶广义积分器软件锁相环初始化函数
 *@param p 二阶广义积分器软件锁相环结构体
 *@param freq_ref 跟踪频率（Hz)
 *@param Ts 计算时间
 */
void SOGI_SPLL_Init(SOGI_SPLL_STRUCT *p, float freq_ref, float Ts)
{
    p->Ts = Ts;
    p->woref = 6.2831853f * freq_ref;
    p->wo = 0;
    p->sogi_k = 1.414f;
    p->sogi_a = 0;
    p->sogi_b = 0;
    p->freq = 0;
    p->theta = 0;
    p->pi_ek0 = 0;
    p->pi_ek1 = 0;
    p->pi_kp = 3.28f;
    p->pi_ki = 6.1f;
    p->pi_out = 0;
}

/*
 *@brief 二阶广义积分器软件锁相环计算函数
 *@param p 二阶广义积分器软件锁相环结构体
 *@param uin 输入信号（单相正弦）
 */
void SOGI_SPLL_calc(SOGI_SPLL_STRUCT *p, float uin)
{
    /* SOGI */
    p->sogi_a += ((uin - p->sogi_a) * p->sogi_k - p->sogi_b) * p->wo * p->Ts;
    p->sogi_b += p->sogi_a * p->wo * p->Ts;
    /* Park(cos) */
    float p_cos = cos(p->theta);
    float p_sin = sin(p->theta);
    p->ud = p_cos * p->sogi_a + p_sin * p->sogi_b;
    p->uq = p_cos * p->sogi_b - p_sin * p->sogi_a;
    /* PI */
    p->pi_ek0 = 0 - p->uq;
    p->pi_out = p->pi_kp * (p->pi_ek0 - p->pi_ek1) - p->pi_ki * p->pi_ek0;
    p->wo = p->pi_out + p->woref;
    p->pi_ek1 = p->pi_ek0;
    /* Limit */
    p->wo = p->wo > 58.5f * 6.2831853f ? 58.5f * 6.2831853f : p->wo;
    p->wo = p->wo < 41.5f * 6.2831853f ? 41.5f * 6.2831853f : p->wo;
    /* Integrator */
    p->theta += p->wo * p->Ts;
    if (p->theta > +6.2831853f)
    {
        p->theta -= 6.2831853f;
    }
}

/*
 *@brief 单同步坐标系软件锁相环初始化函数
 *@param p 单同步坐标系软件锁相环结构体
 *@param freq_ref 跟踪频率（Hz)
 *@param Ts 计算时间
 */
void SRF_SPLL_Init(SSRF_SPLL_STRUCT *p, float freq_ref, float Ts)
{
    p->Ts = Ts;
    p->woref = 6.2831853f * freq_ref;
    p->wo = 0;
    p->freq = 0;
    p->theta = 0;
    p->pi_ek0 = 0;
    p->pi_ek1 = 0;
    p->pi_kp = 3.28f;
    p->pi_ki = 6.1f;
    p->pi_out = 0;
}

/*
 *@brief 单同步坐标系软件锁相环计算函数
 *@param p 单同步坐标系软件锁相环结构体
 *@param ud DQ坐标系下的D轴分量
 *@param uq DQ坐标系下的Q轴分量
 */
void SRF_SPLL_calc(SSRF_SPLL_STRUCT *p, float ud, float uq)
{
    /* PI */
    p->pi_ek0 = 0 - uq;
    p->pi_out = p->pi_kp * (p->pi_ek0 - p->pi_ek1) - p->pi_ki * p->pi_ek0;
    p->wo = p->pi_out + p->woref;
    p->pi_ek1 = p->pi_ek0;
    /* Limit */
    p->wo = p->wo > 58.5f * 6.2831853f ? 58.5f * 6.2831853f : p->wo;
    p->wo = p->wo < 41.5f * 6.2831853f ? 41.5f * 6.2831853f : p->wo;
    /* Integrator */
    p->theta += p->wo * p->Ts;
    if (p->theta > +6.2831853f)
    {
        p->theta -= 6.2831853f;
    }
}

/*
 *@brief 双二阶广义积分器软件锁相环初始化函数
 *@param p 双二阶广义积分器软件锁相环结构体
 *@param freq_ref 跟踪频率（Hz)
 *@param Ts 计算时间
 */
void DSOGI_SPLL_Init(DSOGI_SPLL_STRUCT *p, float freq_ref, float Ts)
{
    p->Ts = Ts;
    p->wo = 6.2831853f * freq_ref;
    p->woref = 6.2831853f * freq_ref;
    p->theta = 0;
    p->freq = 0;
    p->sogi_k = 1.414f;
    p->sogi_a1 = 0;
    p->sogi_a2 = 0;
    p->sogi_b1 = 0;
    p->sogi_b2 = 0;
    p->tem_alpha = 0;
    p->tem_beta = 0;
    p->ud = 0;
    p->uq = 0;
    p->pi_ek0 = 0;
    p->pi_ek1 = 0;
    p->pi_kp = 3.28f;
    p->pi_ki = 6.1f;
    p->pi_out = 0;
}

/*
 *@brief 双二阶广义积分器软件锁相环计算函数
 *@param p 双二阶广义积分器软件锁相环结构体
 *@param alpha 两相静止坐标系下的alpha轴分量
 *@param beta  两相静止坐标系下的beta轴分量
 */
void DSOGI_SPLL_calc(DSOGI_SPLL_STRUCT *p, float alpha, float beta)
{
    /* DSOGI */
    p->sogi_a1 += ((alpha - p->sogi_a1) * p->sogi_k - p->sogi_b1) * p->wo * p->Ts;
    p->sogi_b1 += p->sogi_a1 * p->wo * p->Ts;
    p->sogi_a2 += ((beta - p->sogi_a2) * p->sogi_k - p->sogi_b2) * p->wo * p->Ts;
    p->sogi_b2 += p->sogi_a2 * p->wo * p->Ts;
    p->tem_alpha = p->sogi_a1 - p->sogi_b2;
    p->tem_beta = p->sogi_b1 + p->sogi_a2;
    /* Park(cos) */
    float p_cos = cos(p->theta);
    float p_sin = sin(p->theta);
    p->ud = p_cos * p->tem_alpha + p_sin * p->tem_beta;
    p->uq = p_cos * p->tem_beta - p_sin * p->tem_alpha;
    /* PI */
    p->pi_ek0 = 0 - p->uq;
    p->pi_out = p->pi_kp * (p->pi_ek0 - p->pi_ek1) - p->pi_ki * p->pi_ek0;
    p->wo = p->pi_out + p->woref;
    p->pi_ek1 = p->pi_ek0;
    /* Limit */
    p->wo = p->wo > 58.5f * 6.2831853f ? 58.5f * 6.2831853f : p->wo;
    p->wo = p->wo < 41.5f * 6.2831853f ? 41.5f * 6.2831853f : p->wo;
    /* Integrator */
    p->theta += p->wo * p->Ts;
    if (p->theta > +6.2831853f)
    {
        p->theta -= 6.2831853f;
    }
}

#ifndef __SPLL_H
#define __SPLL_H

#include "math.h"
// #include "arm_math.h" /*使用DSP库函数的话可以将sin、cos函数替换，提高运算速度*/

/* 二阶广义积分器软件锁相环 */
typedef struct
{
    float sogi_k;    
    float sogi_a;
    float sogi_b;

    float ud;
    float uq;

    float pi_ek0;
    float pi_ek1;
    float pi_kp;
    float pi_ki;
    float pi_out;

    float woref;
    float wo;
    float freq;
    float theta;
    float Ts;
}SOGI_SPLL_STRUCT;
extern SOGI_SPLL_STRUCT sogi2;
void SOGI_SPLL_Init(SOGI_SPLL_STRUCT*p,float freq_ref,float Ts);
void SOGI_SPLL_calc(SOGI_SPLL_STRUCT*p,float uin);

/* 单同步坐标系软件锁相环 */
typedef struct
{
    float pi_ek0;
    float pi_ek1;
    float pi_kp;
    float pi_ki;
    float pi_out;

    float woref;
    float wo;
    float freq;
    float theta;
    float Ts;
}SSRF_SPLL_STRUCT;

void SRF_SPLL_Init(SSRF_SPLL_STRUCT*p,float freq_ref,float Ts);
void SRF_SPLL_calc(SSRF_SPLL_STRUCT*p,float ud,float uq);

/* 双二阶广义积分器软件锁相环 */
typedef struct
{
    float sogi_k;    
    float sogi_a1;
    float sogi_b1;
    float sogi_a2;
    float sogi_b2;
    float tem_alpha;
    float tem_beta;

    float ud;
    float uq;

    float pi_ek0;
    float pi_ek1;
    float pi_kp;
    float pi_ki;
    float pi_out;

    float wo;
    float woref;
    float freq;
    float theta;
    float Ts;
}DSOGI_SPLL_STRUCT;

void DSOGI_SPLL_Init(DSOGI_SPLL_STRUCT*p,float freq_ref,float Ts);
void DSOGI_SPLL_calc(DSOGI_SPLL_STRUCT*p,float alpha,float beta);

#endif

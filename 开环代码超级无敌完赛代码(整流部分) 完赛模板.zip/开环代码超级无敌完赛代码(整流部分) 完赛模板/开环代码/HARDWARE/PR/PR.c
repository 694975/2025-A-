#include "PR.h"

void PR_Init(PR_CONTROLLER *pr, float kp, float kr, float ts, float wc, float wo)
{
    // �����������
    pr->Ts = ts;
    pr->Kp = kp;
    pr->Kr = kr;
    pr->wc = wc;
    pr->wo = wo;

    // ����ԭʼϵ��
    pr->b0 = 4 / (ts * ts) + 4 * wc / ts + wo * wo;
    pr->a0 = (4 * kp / (ts * ts) + 4 * wc * (kp + kr) / ts + kp * wo * wo);
    pr->a1 = (-8 * kp / (ts * ts) + 2 * kp * wo * wo);
    pr->a2 = (4 * kp / (ts * ts) - 4 * wc * (kp + kr) / ts + kp * wo * wo);
    pr->b1 = (-8 / (ts * ts) + 2 * wo * wo);
    pr->b2 = (4 / (ts * ts) - 4 * wc / ts + wo * wo);
    
    // �����һ��ϵ��
    pr->B1 = -pr->b1 / pr->b0;
    pr->B2 = -pr->b2 / pr->b0;
    pr->A0 = pr->a0 / pr->b0;
    pr->A1 = pr->a1 / pr->b0;
    pr->A2 = pr->a2 / pr->b0;
    
    // ��ʼ��״̬����
    pr->vo = 0.0f;
    pr->vo_1 = 0.0f;
    pr->vo_2 = 0.0f;
    pr->vi = 0.0f;
    pr->vi_1 = 0.0f;
    pr->vi_2 = 0.0f;
}

float PR_Calculate(PR_CONTROLLER *pr, float ref, float feedback)
{
    // �������
    pr->vi = ref - feedback;
    
    // ʹ�ù�һ��ϵ���������
    pr->vo = pr->B1 * pr->vo_1 
           + pr->B2 * pr->vo_2 
           + pr->A0 * pr->vi 
           + pr->A1 * pr->vi_1
           + pr->A2 * pr->vi_2;
    
    // ������ʷ״̬
    pr->vo_2 = pr->vo_1;
    pr->vo_1 = pr->vo;
    pr->vi_2 = pr->vi_1;
    pr->vi_1 = pr->vi;
    
    return pr->vo;
}
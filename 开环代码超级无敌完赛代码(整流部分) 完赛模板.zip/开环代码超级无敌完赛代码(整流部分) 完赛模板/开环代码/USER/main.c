#include "pll_single_phase.h"
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "pwm.h"
#include "timer.h"
#include "OLED.h"
#include "adc.h"
#include "PID.h"
#include "PR.h"
#include "SPLL.h"
#include "button4_4.h"
#include "SOGI_PLL.h"
#include "arm_math.h" 
#include <string.h>
//ALIENTEK ̽����STM32F407������ ʵ��9
//PWM���ʵ��-�⺯���汾
//����֧�֣�www.openedv.com
//�Ա����̣�http://eboard.taobao.com  
//�������������ӿƼ����޹�˾  
//���ߣ�����ԭ�� @ALIENTEK
int spwm[400]=
{500,507,514,521,528,535,542,549,556,563,570,577,584,591,598,605,
611,618,625,632,639,645,652,659,665,672,678,685,691,697,704,710,
716,722,729,735,741,747,752,758,764,770,775,781,786,792,797,802,
808,813,818,823,828,832,837,842,846,851,855,859,864,868,872,876,
879,883,887,890,894,897,900,904,907,910,912,915,918,920,923,925,
927,930,932,934,935,937,939,940,942,943,944,945,946,947,948,948,
949,949,949,949,950,949,949,949,949,948,948,947,946,945,944,943,
942,940,939,937,935,934,932,930,927,925,923,920,918,915,912,910,
907,904,900,897,894,890,887,883,879,876,872,868,864,859,855,851,
846,842,837,832,828,823,818,813,808,802,797,792,786,781,775,770,
764,758,752,747,741,735,729,722,716,710,704,697,691,685,678,672,
665,659,652,645,639,632,625,618,611,605,598,591,584,577,570,563,
556,549,542,535,528,521,514,507,500,492,485,478,471,464,457,450,
443,436,429,422,415,408,401,394,388,381,374,367,360,354,347,340,
334,327,321,314,308,302,295,289,283,277,270,264,258,252,247,241,
235,229,224,218,213,207,202,197,191,186,181,176,171,167,162,157,
153,148,144,140,135,131,127,123,120,116,112,109,105,102,99,95,
92,89,87,84,81,79,76,74,72,69,67,65,64,62,60,59,
57,56,55,54,53,52,51,51,50,50,50,50,50,50,50,50,
50,51,51,52,53,54,55,56,57,59,60,62,64,65,67,69,
72,74,76,79,81,84,87,89,92,95,99,102,105,109,112,116,
120,123,127,131,135,140,144,148,153,157,162,167,171,176,181,186,
191,197,202,207,213,218,224,229,235,241,247,252,258,264,270,277,
283,289,295,302,308,314,321,327,334,340,347,354,360,367,374,381,
388,394,401,408,415,422,429,436,443,450,457,464,471,478,485,492};
int spwm1[400]={500,507,515,523,531,539,547,554,562,570,578,585,593,601,609,616,
624,631,639,647,654,661,669,676,684,691,698,705,712,719,726,733,
740,747,754,761,767,774,781,787,793,800,806,812,818,824,830,836,
842,847,853,859,864,869,875,880,885,890,895,899,904,909,913,917,
922,926,930,934,938,941,945,949,952,955,958,961,964,967,970,973,
975,977,980,982,984,986,987,989,991,992,993,995,996,996,997,998,
999,999,999,999,1000,999,999,999,999,998,997,996,996,995,993,992,
991,989,987,986,984,982,980,977,975,973,970,967,964,961,958,955,
952,949,945,941,938,934,930,926,922,917,913,909,904,899,895,890,
885,880,875,869,864,859,853,847,842,836,830,824,818,812,806,800,
793,787,781,774,767,761,754,747,740,733,726,719,712,705,698,691,
684,676,669,661,654,647,639,631,624,616,609,601,593,585,578,570,
562,554,547,539,531,523,515,507,500,492,484,476,468,460,452,445,
437,429,421,414,406,398,390,383,375,368,360,352,345,338,330,323,
315,308,301,294,287,280,273,266,259,252,245,238,232,225,218,212,
206,199,193,187,181,175,169,163,157,152,146,140,135,130,124,119,
114,109,104,100,95,90,86,82,77,73,69,65,61,58,54,50,
47,44,41,38,35,32,29,26,24,22,19,17,15,13,12,10,
8,7,6,4,3,3,2,1,0,0,0,0,0,0,0,0,
0,1,2,3,3,4,6,7,8,10,12,13,15,17,19,22,
24,26,29,32,35,38,41,44,47,50,54,58,61,65,69,73,
77,82,86,90,95,100,104,109,114,119,124,130,135,140,146,152,
157,163,169,175,181,187,193,199,206,212,218,225,232,238,245,252,
259,266,273,280,287,294,301,308,315,323,330,338,345,352,360,368,
375,383,390,398,406,414,421,429,437,445,452,460,468,476,484,492};
//int spwm1[600]=
//{500,504,508,512,516,520,525,529,533,537,541,545,550,554,558,562,
//566,570,574,579,583,587,591,595,599,603,607,611,615,619,623,627,
//631,635,639,643,647,651,655,658,662,666,670,674,677,681,685,689,
//692,696,700,703,707,710,714,717,721,724,728,731,735,738,741,745,
//748,751,754,758,761,764,767,770,773,776,779,782,785,788,791,794,
//797,800,802,805,808,810,813,816,818,821,823,826,828,830,833,835,
//837,839,842,844,846,848,850,852,854,856,858,860,861,863,865,867,
//868,870,871,873,874,876,877,879,880,881,882,884,885,886,887,888,
//889,890,891,892,892,893,894,895,895,896,896,897,897,898,898,898,
//899,899,899,899,899,899,900,899,899,899,899,899,899,898,898,898,
//897,897,896,896,895,895,894,893,892,892,891,890,889,888,887,886,
//885,884,882,881,880,879,877,876,874,873,871,870,868,867,865,863,
//861,860,858,856,854,852,850,848,846,844,842,839,837,835,833,830,
//828,826,823,821,818,816,813,810,808,805,802,800,797,794,791,788,
//785,782,779,776,773,770,767,764,761,758,754,751,748,745,741,738,
//735,731,728,724,721,717,714,710,707,703,700,696,692,689,685,681,
//677,674,670,666,662,658,655,651,647,643,639,635,631,627,623,619,
//615,611,607,603,599,595,591,587,583,579,574,570,566,562,558,554,
//550,545,541,537,533,529,525,520,516,512,508,504,500,495,491,487,
//483,479,474,470,466,462,458,454,449,445,441,437,433,429,425,420,
//416,412,408,404,400,396,392,388,384,380,376,372,368,364,360,356,
//352,348,344,341,337,333,329,325,322,318,314,310,307,303,300,296,
//292,289,285,282,278,275,271,268,264,261,258,254,251,248,245,241,
//238,235,232,229,226,223,220,217,214,211,208,205,202,199,197,194,
//191,189,186,183,181,178,176,173,171,169,166,164,162,160,157,155,
//153,151,149,147,145,143,141,139,138,136,134,132,131,129,128,126,
//125,123,122,120,119,118,117,115,114,113,112,111,110,109,108,107,
//107,106,105,104,104,103,103,102,102,101,101,101,100,100,100,100,
//100,100,100,100,100,100,100,100,100,101,101,101,102,102,103,103,
//104,104,105,106,107,107,108,109,110,111,112,113,114,115,117,118,
//119,120,122,123,125,126,128,129,131,132,134,136,138,139,141,143,
//145,147,149,151,153,155,157,160,162,164,166,169,171,173,176,178,
//181,183,186,189,191,194,197,199,202,205,208,211,214,217,220,223,
//226,229,232,235,238,241,245,248,251,254,258,261,264,268,271,275,
//278,282,285,289,292,296,300,303,307,310,314,318,322,325,329,333,
//337,341,344,348,352,356,360,364,368,372,376,380,384,388,392,396,
//400,404,408,412,416,420,425,429,433,437,441,445,449,454,458,462,
//466,470,474,479,483,487,491,495};

//void get_cos(void)
//{
//	int j;
//  float hudu;
//	hudu=2.0f*3.14159/400.0f;
//	for(j=0;j<400;j++)
//{
//  cosdata[j]=311.0f*cos(hudu*j);
//}
//}

int i=0;;//A��
int j=266;//B��
int k=133;//C��
int m=0;
float A_sinth=0;//A��λSVPWM
float B_sinth=0;//B��λSVPWM
float C_sinth=0;//C��λSVPWM
float Phase_A=0;//��λ��
float Phase_B=0;//��λ��
float Phase_C=0;//��λ��
float sin_A=0;//A��׼��
float sin_B=0;//B��׼��
float sin_C=0;//C��׼��
float Target_voliate=31.20f;
float sin_a=0, sin_b=0, sin_c=0;//���������� 
//����PR���
float pid_A=0;
float pid_B=0;
float pid_C=0;
float Target_I=1.5f;
float iref=0;
int keynum=0;
float Frequency=50.0f;
float volatile_k=0.90;
float costh=0;
int t=0;
int x=0;
float PID_out=0;
float PID_Current_value=500;
float DC_AC_costh=0;
int SPWM_flag=0;//����
int PID_flag=0;//PID����
int change_f=0;//��Ƶ
int SVPWM_flag=0;//SVPWM����
SOGI_PLL sogi;
SOGI_PLL sogi1;
SOGI_SPLL_STRUCT sogi2;
PLL_State pll_state;
PR_CONTROLLER PR_UA;
PR_CONTROLLER PR_UB;
PR_CONTROLLER PR_UC;
int tiaozhidu=500;
float angle=0;
float ua=0;//svpwm A��
float ub=0;//svpwm B��
float uc=0;//svpwm C��
float udc=0; //������ѹ
// �������Ҳ�������
void epwm_control_three_spwm(float a, float b, float c, float Offset,float udc)
	{
    float a1, b1, c1;
    float max_val, min_val;
    float Voffset;
   
    // ������ֵ����Ԥ����
    a1 = (1.0*a/udc + Offset) / 2.0f;
    b1 = (1.0*b/udc + Offset) / 2.0f;
    c1 = (1.0*c/udc + Offset) / 2.0f; 
    //�������ֵ
    max_val = a1;
    if (b1 > max_val) max_val = b1;
    if (c1 > max_val) max_val = c1; 
    // ������Сֵ
    min_val = a1;
    if (b1 < min_val) min_val = b1;
    if (c1 < min_val) min_val = c1;
    // ��������ƫ����
    Voffset = 0.5f * (Offset - (max_val + min_val));
    // ע��ƫ��������������ռ�ձ�
    sin_a = a1 + Voffset;
    sin_b = b1 + Voffset;
    sin_c = c1 + Voffset;  
		//�����޷�
//		a1=fmaxf(fminf(a1,0.9f),0.1f);  // �޷�
//		b1=fmaxf(fminf(b1,0.9f),0.1f);  // �޷�
//		c1=fmaxf(fminf(c1,0.9f),0.1f);  // �޷�	
		if(sin_a < 0.1f) sin_a = 0.1f;
    if(sin_a > 0.9f) sin_a = 0.9f;
    if(sin_b < 0.1f) sin_b = 0.1f;
    if(sin_b > 0.9f) sin_b = 0.9f;
    if(sin_c < 0.1f) sin_c = 0.1f;
    if(sin_c > 0.9f) sin_c = 0.9f;
    // Ӧ��ռ�ձȵ�TIM1������ͨ�� (ʹ��Ĭ�ϵ�TIM���)
   TIM_SetCompare1(TIM1,1000*sin_a);  // PA8 (U��)
   TIM_SetCompare2(TIM1,1000*sin_b);  // PA9 (V��)
   TIM_SetCompare3(TIM1,1000*sin_c);  // PA10(W��)
//	 TIM_SetCompare1(TIM1,1000*a1);  // PA8 (U��)
//   TIM_SetCompare2(TIM1,1000*b1);  // PA9 (V��)
//   TIM_SetCompare3(TIM1,1000*c1);  // PA10(W��)
//     TIM_SetCompare1(TIM1,500);  // PA8 (U��)
//     TIM_SetCompare2(TIM1,500);  // PA9 (V��)
//     TIM_SetCompare3(TIM1,500);
}
int main(void)
{  
	  //generate_sine_table();
	  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	  delay_init(168);  //��ʼ����ʱ����
	  //
	  //TIM1_Center_PWM_Init(1000, 4);	 
	
    PID_Init();  
	  SOGI_PLL_Init(&sogi,0.0001f,50,1.0f,1.0f,0.05f,0.0f,10000.0f,-10000.0f,10,-10);  
	  SOGI_PLL_Init(&sogi1,0.0005f,50,1.0f,1.0f,0.05f,0.0f,10000.0f,-10000.0f,10,-10);
	//���׷�����0.925��������
	  PR_Init(&PR_UA, 9.0f, 50.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
    PR_Init(&PR_UB, 9.0f, 50.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
    PR_Init(&PR_UC, 9.0f, 50.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
	//
  //PR_Init(&PR_UA, 1.5f, 39.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
  //PR_Init(&PR_UB, 1.5f, 39.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
  //PR_Init(&PR_UC, 1.5f, 39.0f, 0.0001f, PI_F * 5.0f, 2.0f * PI_F * 50.f);
	  ADC_DMA_Init();
	 // TIM3_PWM_Init(1000-1,4-1);	//84M/84=1Mhz�ļ���Ƶ��,��װ��ֵ500������PWMƵ��Ϊ 1M/500=2Khz. 
	 // TIM8_PWM_Init(1000, 7);
	  //TIM1_PWM_Init(1000, 6);
	  OLED_Init();
	  Current_PID_Init(&Current_PID);
	  Volatile_DCPID_Init(&DC_PID);
	  uart_init(460800);
    Button4_4_Init();
		//TIM2_Int_Init(100-1,84-1);
	  TIM5_Int_Init(50-1,84-1);
	  TIM4_Int_Init(100-1,84-1);		
    //TIM_SetCompare1(TIM1, 500); 
	  //��ʼ�����ڲ�����Ϊ115200  
    //OLED��ʼ��
    while(1) //ʵ�ֱȽ�ֵ��0-300��������300���300-0�ݼ���ѭ��
 	   {			 
     //printf("%.3f,%.3f,%.3f,%.3f\n",-AD_current_ref,-AD_current_ref1,-AD_current_ref2,AD_Voliate1);
     //printf("samples:%f, %f, %f, %f\n",AD_current1 ,costh,AD_current_ref, PID_Current_value);
     keynum=Button4_4_Scan();
		if(keynum==1)
    {
		 SPWM_flag+=1;
		 SPWM_flag%=2;
		}
	  if(keynum==2)
    {
	   PID_flag+=1;
		 PID_flag%=2;	
	  }
		if(keynum==3)
    {
	   change_f+=1;
		 change_f%=2;	
	  }
		if(keynum==4)
    {
	  SVPWM_flag+=1;
	  SVPWM_flag%=2;
	  }
		if(keynum==5)
    {
	   Frequency+=1;		 
	  }
	  if(keynum==6)
    {
	   Frequency-=1;
	  }
		if(keynum==7)
    {
		Target_voliate-=0.1;
		}
		if(keynum==8)
    {
		Target_voliate+=0.1;
		}
		if(keynum==9)
   {
	   Target_I+=0.1;
	 }
	 	if(keynum==10)
   {
	   Target_I-=0.1;
	 }
		if(SPWM_flag==1&&x==0)
   {
	  TIM8_PWM_Init(1000, 7);
	     x=1;
	 }
		if(SVPWM_flag==1&&t==0)
   { 
	  TIM1_Center_PWM_Init(1000, 4);	
	             t=1; 
	 }
   OLED_ShowNum(0,0,SPWM_flag, 1,OLED_8X16);//��������
 //  OLED_ShowNum(0,0,keynum, 2,OLED_8X16);//��������
 	 OLED_ShowNum(0,16, PID_flag,1, OLED_8X16);//�������� 
	 OLED_ShowNum(0,32,  change_f,1, OLED_8X16);//�������� 
	 OLED_ShowNum(0,48,  SVPWM_flag,1, OLED_8X16);
   OLED_ShowNum(16,0,Frequency,2,OLED_8X16);//��䷢��
   OLED_ShowNum(20,48,AD_Voliate_Value3 ,2,OLED_8X16);//������
	 OLED_ShowNum(40,48,(uint16_t)(AD_Voliate_Value3  * 100) % 100, 2,OLED_8X16);
	 OLED_ShowNum(20,32,Target_voliate ,2,OLED_8X16);//������
	 OLED_ShowNum(40,32,(uint16_t)(Target_voliate  * 100) % 100, 2,OLED_8X16);
   OLED_ShowNum(20,16,volatile_k ,1,OLED_8X16);//������
	 OLED_ShowNum(40,16,(uint16_t)(volatile_k*100)%100 ,2,OLED_8X16);//������
	 OLED_ShowNum(40,0,Target_I,1,OLED_8X16);//��䷢��
	 OLED_ShowNum(48,0,(uint16_t)(Target_I*10)%10,1,OLED_8X16);//��䷢��
//// OLED_ShowNum(20,48,(uint16_t)(AD_Voliate_Value3  * 100) % 100, 2,OLED_8X16);
////	 //OLED_ShowNum(16,0, DC_AC_PID_PLL_flag, 1,OLED_8X16);//������ࡢ
////	 //OLED_ShowNum(16,16, DC_AC_Init_flag, 1,OLED_8X16);//����ֹͣ
////   //OLED_ShowNum(16,32, AC_DC_Init_flag, 1,OLED_8X16);//����ֹͣ		
 OLED_Update();
	   }
     }
//�������жϴ���
void TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET) //����ж�
	 { 		
     //average_DC_AC_voliate();
   }	
	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);  //����жϱ�־λ
}
//���෢��+PID�����ж�
void TIM5_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM5,TIM_IT_Update)==SET) //����ж�
	{ 
//���� 	
	   average_DC_AC_voliate();
  	//��Ƶ
		static float PhaseA = 0.0f;
    // ��ʼ�ǶȻ��֣�����ʵ��Ts��
    PhaseA += 6.283185307179586f * Frequency * 0.00005f;		
    // ��λ��һ����������0~2�У�
    if (PhaseA > 6.283185307179586f) PhaseA -= 6.283185307179586f;
    if (PhaseA < 0) PhaseA += 6.283185307179586f;	
    // ����B����λ���ͺ�A��120�ȣ���2��/3��
    float PhaseB = PhaseA - 6.283185307179586f * 0.3333333f;
    if (PhaseB > 6.283185307179586f) PhaseB -= 6.283185307179586f;
    if (PhaseB < 0) PhaseB += 6.283185307179586f;
    // ����C����λ����ǰA��120�ȣ���2��/3��
    float PhaseC = PhaseA + 6.283185307179586f * 0.3333333f;
    if (PhaseC > 6.283185307179586f) PhaseC -= 6.283185307179586f;
    if (PhaseC < 0) PhaseC += 6.283185307179586f;	
	  //��Ƶ����
    // ͨ��ָ�봫�ݼ�������ԭ����Ϊֵ���ݣ��޷����������
    A_sinth = arm_sin_f32(PhaseA);  // ��ʹ��CMSIS��arm_sin_f32�������Ӧͷ�ļ�
    B_sinth = arm_sin_f32(PhaseB);
    C_sinth = arm_sin_f32(PhaseC); 
   if(SPWM_flag==1&&change_f==0)
		  {
      TIM_SetCompare1(TIM8,spwm[i]);//A��
   		TIM_SetCompare2(TIM8,spwm[j]);//B��
		  TIM_SetCompare3(TIM8,spwm[k]);//C��     
		  if(SPWM_flag==1&& PID_flag==1&&DC_AC_flag==1)
		 {		
	     volatile_k+=PID_Volatite_calc(Target_voliate-AD_Voliate_Value3);
		   if(volatile_k>=0.95)
       {
		   volatile_k=0.95;
			 }
			 if(volatile_k<=0)
       {
			  volatile_k=0;
		   }
      TIM_SetCompare1(TIM8,500+(spwm1[i]-500)*volatile_k);//A��
   		TIM_SetCompare2(TIM8,500+(spwm1[j]-500)*volatile_k);//B��
		  TIM_SetCompare3(TIM8,500+(spwm1[k]-500)*volatile_k);//C��
		 }
		 	if(SPWM_flag==1&& PID_flag==1&&DC_AC_flag==0)
		 {		
      TIM_SetCompare1(TIM8,500+(spwm1[i]-500)*volatile_k);//A��
   		TIM_SetCompare2(TIM8,500+(spwm1[j]-500)*volatile_k);//B��
		  TIM_SetCompare3(TIM8,500+(spwm1[k]-500)*volatile_k);//C��
		 }
	   }
		 if(change_f==1)
     {
	    TIM_SetCompare1(TIM8,500+A_sinth*500*0.92);//A��
   		TIM_SetCompare2(TIM8,500+B_sinth*500*0.92);//B��
		  TIM_SetCompare3(TIM8,500+C_sinth*500*0.92);//C��	  
	   }
		 i++;
		 j++;
		 k++;
		 i%=400;
		 j%=400;
		 k%=400;
	}
	TIM_ClearITPendingBit(TIM5,TIM_IT_Update);  //����жϱ�־λ
}
 
//�������� 
void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)==SET) //����ж�
	{ 	 
		   average_current();  //�����е���
       average_voliate();	 //��������ߵ�ѹ	
     //void epwm_control_three_spwm(float a, float b, float c, float Offset);
		   SOGI_PLL_ProcessSample(&sogi,AD_Voliate_ref);	//����ĵ����ǵ�ѹ�Ĳ���		
		   Phase_A=sogi.phase;
		   sin_A= arm_cos_f32(Phase_A);
		   float Phase_B = Phase_A - 6.283185307179586f * 0.3333333f;
       if (Phase_B > 6.283185307179586f) Phase_B -= 6.283185307179586f;
       if (Phase_B < 0) Phase_B += 6.283185307179586f;
		   sin_B= arm_cos_f32(Phase_B);
      // ����C����λ����ǰA��120�ȣ���2��/3��
       float Phase_C = Phase_A+ 6.283185307179586f * 0.3333333f;
       if (Phase_C > 6.283185307179586f) Phase_C -= 6.283185307179586f;
       if (Phase_C < 0) Phase_C += 6.283185307179586f;	
		   sin_C= arm_cos_f32(Phase_C);
    if(SVPWM_flag==1&&t==1)
    { 		
		   pid_A=AD_Voliate_Value*sin_A*1.414-PR_Calculate(&PR_UA,1.414*sin_A*Target_I,-AD_current_ref);//A��
		   pid_B=AD_Voliate_Value*sin_B*1.414-PR_Calculate(&PR_UB,1.414*sin_B*Target_I,-AD_current_ref1);//B��
		   pid_C=AD_Voliate_Value*sin_C*1.414-PR_Calculate(&PR_UC,1.414*sin_C*Target_I,-AD_current_ref2);//C��
////       TIM_SetCompare1(TIM1,500);  // PA8 (U��)
////       TIM_SetCompare2(TIM1,500);  // PA9 (V��)
////       TIM_SetCompare3(TIM1,500);		
       epwm_control_three_spwm( pid_A, pid_B, pid_C, 1.0f, AD_Voliate1);
		}
			 
		   
//		   SOGI_PLL_ProcessSample(&sogi,AD_current_ref1);
//       costh=-arm_cos_f32(sogi.phase);
//		   iref=1.414*costh*0.9;
//			if(PID_Current_value>=10)
//      {
//		   PID_Current_value=10;	
//		  }
//		  if(PID_Current_value<=-10)
//      {
//		  PID_Current_value=-10;	
//		  }
//       float normalized_value = (PID_Current_value + 10.0f) / 20.0f;	

//		if(SPWM_flag==1&&PID_flag==1)
//     {
//		  TIM_SetCompare1(TIM1,1000-normalized_value*990); 
//		  TIM_SetCompare2(TIM1,normalized_value*990); 
//	   }		
//		if(SPWM_flag==1&&PID_flag==0)
//		 {
//		  TIM_SetCompare1(TIM1,500+500*0.9*costh);//PE9 Q1��
//		  TIM_SetCompare2(TIM1,1000-(500+500*0.9*costh));//PE11 Q��
//		 }
 }
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);  //����жϱ�־λ
}




